# Web de ciencia

Web de ciencia hecha con HTML, CSS y Django

**Tema: Ciencia**

## Secciones:
- Noticias
- Canales Recomendados
- Lugares Científicos de Chile
- Blog